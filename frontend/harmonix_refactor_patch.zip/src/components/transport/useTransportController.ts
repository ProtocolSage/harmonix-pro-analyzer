import { useState, useRef, useEffect, useCallback } from 'react';
import type { AudioAnalysisResult } from '../../types/audio';
import { RealtimeVisualizationEngine, type AudioVisualizationData } from '../../engines/RealtimeVisualizationEngine';

export interface UseTransportControllerArgs {
  audioFile: File | null;
  isAnalyzing: boolean;
  analysisData?: AudioAnalysisResult | null;
  onPlaybackProgress?: (currentTime: number, duration: number) => void;
  onPlaybackStateChange?: (isPlaying: boolean) => void;
  enableRealtimeVisualization?: boolean;
  seekToTime?: number | null;
  onSeekApplied?: () => void;
}

export interface PlaybackState {
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isRepeat: boolean;
  isShuffle: boolean;
}

export function useTransportController(args: UseTransportControllerArgs) {
  const {
    audioFile,
    isAnalyzing,
    analysisData,
    onPlaybackProgress,
    onPlaybackStateChange,
    enableRealtimeVisualization = true,
    seekToTime,
    onSeekApplied,
  } = args;

  const audioRef = useRef<HTMLAudioElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);
  const visualizationCanvasRef = useRef<HTMLCanvasElement>(null);
  const visualizationEngineRef = useRef<RealtimeVisualizationEngine | null>(null);

  const [isDragging, setIsDragging] = useState(false);
  const [visualizationData, setVisualizationData] = useState<AudioVisualizationData | null>(null);

  const [playbackState, setPlaybackState] = useState<PlaybackState>({
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    volume: 0.8,
    isMuted: false,
    isRepeat: false,
    isShuffle: false
  });

  audioFile,
  isAnalyzing,
  analysisData,
  onPlaybackProgress,
  onPlaybackStateChange,
  enableRealtimeVisualization = true,
  compact = false,
  seekToTime,
  onSeekApplied,
}: TransportControlsProps) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);
  const visualizationCanvasRef = useRef<HTMLCanvasElement>(null);
  const visualizationEngineRef = useRef<RealtimeVisualizationEngine | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [visualizationData, setVisualizationData] = useState<AudioVisualizationData | null>(null);

  const [playbackState, setPlaybackState] = useState<PlaybackState>({
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    volume: 0.8,
    isMuted: false,
    isRepeat: false,
    isShuffle: false
  });

  // Initialize realtime visualization engine
  const visualizationEnabled = enableRealtimeVisualization;

  useEffect(() => {
    if (visualizationEnabled && visualizationCanvasRef.current && !visualizationEngineRef.current) {
      try {
        visualizationEngineRef.current = new RealtimeVisualizationEngine(visualizationCanvasRef.current, {
          fps: 60,
          showWaveform: true,
          showSpectrum: true,
          showBeats: true,
          colorScheme: 'default'
        });

        // Set up visualization data callback
        const unsubscribe = visualizationEngineRef.current.onVisualizationData((data) => {
          setVisualizationData(data);
        });

        return () => {
          unsubscribe();
          if (visualizationEngineRef.current) {
            visualizationEngineRef.current.destroy();
            visualizationEngineRef.current = null;
          }
        };
      } catch (error) {
        console.error('Failed to initialize realtime visualization:', error);
      }
    }
  }, [visualizationEnabled]);

  // Update visualization engine with analysis data
  useEffect(() => {
    if (visualizationEngineRef.current && analysisData) {
      visualizationEngineRef.current.setAnalysisData(analysisData);
    }
  }, [analysisData]);

  // Load audio file
  useEffect(() => {
    if (!audioFile || !audioRef.current) return;

    const audio = audioRef.current;
    const objectUrl = URL.createObjectURL(audioFile);

    audio.src = objectUrl;
    audio.volume = playbackState.volume;

    const handleLoadedMetadata = () => {
      setPlaybackState(prev => ({ ...prev, duration: audio.duration }));
      onPlaybackProgress?.(audio.currentTime, audio.duration);
    };

    const handleTimeUpdate = () => {
      if (!isDragging) {
        setPlaybackState(prev => ({ ...prev, currentTime: audio.currentTime }));
        onPlaybackProgress?.(audio.currentTime, audio.duration);
      }
    };

    const handleEnded = () => {
      if (playbackState.isRepeat) {
        audio.currentTime = 0;
        audio.play();
      } else {
        setPlaybackState(prev => ({ ...prev, isPlaying: false, currentTime: 0 }));
        onPlaybackStateChange?.(false);
      }
    };

    const handleError = (e: any) => {
      console.error('Audio playback error:', e);
      setPlaybackState(prev => ({ ...prev, isPlaying: false }));
      onPlaybackStateChange?.(false);
    };

    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);

    return () => {
      URL.revokeObjectURL(objectUrl);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
    };
  }, [audioFile, playbackState.isRepeat, playbackState.volume, isDragging, onPlaybackProgress, onPlaybackStateChange]);

  const togglePlay = useCallback(async () => {
    if (!audioRef.current || isAnalyzing) return;

    const audio = audioRef.current;

    try {
      if (playbackState.isPlaying) {
        audio.pause();
        setPlaybackState(prev => ({ ...prev, isPlaying: false }));
        onPlaybackStateChange?.(false);

        // Stop realtime visualization
        if (visualizationEngineRef.current) {
          visualizationEngineRef.current.stopVisualization();
        }
      } else {
        await audio.play();
        setPlaybackState(prev => ({ ...prev, isPlaying: true }));
        onPlaybackStateChange?.(true);

        // Start realtime visualization
        if (visualizationEngineRef.current && enableRealtimeVisualization) {
          visualizationEngineRef.current.startVisualization(audio);
        }
      }
    } catch (error) {
      console.error('Playback error:', error);
      setPlaybackState(prev => ({ ...prev, isPlaying: false }));
      onPlaybackStateChange?.(false);

      // Stop visualization on error
      if (visualizationEngineRef.current) {
        visualizationEngineRef.current.stopVisualization();
      }
    }
  }, [playbackState.isPlaying, isAnalyzing, onPlaybackStateChange, enableRealtimeVisualization]);

  const stop = useCallback(() => {
    if (!audioRef.current) return;

    const audio = audioRef.current;
    audio.pause();
    audio.currentTime = 0;
    setPlaybackState(prev => ({ ...prev, isPlaying: false, currentTime: 0 }));
    onPlaybackStateChange?.(false);

    // Stop visualization
    if (visualizationEngineRef.current) {
      visualizationEngineRef.current.stopVisualization();
    }
  }, [onPlaybackStateChange]);

  const seek = useCallback((time: number) => {
    if (!audioRef.current) return;

    const audio = audioRef.current;
    audio.currentTime = Math.max(0, Math.min(time, playbackState.duration));
    setPlaybackState(prev => ({ ...prev, currentTime: audio.currentTime }));
  }, [playbackState.duration]);

  const skipBackward = useCallback(() => {
    seek(playbackState.currentTime - 10);
  }, [seek, playbackState.currentTime]);

  const skipForward = useCallback(() => {
    seek(playbackState.currentTime + 10);
  }, [seek, playbackState.currentTime]);

  const toggleMute = useCallback(() => {
    if (!audioRef.current) return;

    const audio = audioRef.current;
    const newMuted = !playbackState.isMuted;

    audio.muted = newMuted;
    setPlaybackState(prev => ({ ...prev, isMuted: newMuted }));
  }, [playbackState.isMuted]);

  const setVolume = useCallback((volume: number) => {
    if (!audioRef.current) return;

    const audio = audioRef.current;
    const clampedVolume = Math.max(0, Math.min(1, volume));

    audio.volume = clampedVolume;
    audio.muted = false;
    setPlaybackState(prev => ({
      ...prev,
      volume: clampedVolume,
      isMuted: false
    }));
  }, []);

  const toggleRepeat = useCallback(() => {
    setPlaybackState(prev => ({ ...prev, isRepeat: !prev.isRepeat }));
  }, []);

  const toggleShuffle = useCallback(() => {
    setPlaybackState(prev => ({ ...prev, isShuffle: !prev.isShuffle }));
  }, []);

  // Progress bar interaction
  const handleProgressClick = useCallback((e: React.MouseEvent) => {
    if (!progressRef.current || playbackState.duration === 0) return;

    const rect = progressRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percentage = clickX / rect.width;
    const newTime = percentage * playbackState.duration;

    seek(newTime);
  }, [seek, playbackState.duration]);

  const handleProgressDrag = useCallback((e: React.MouseEvent) => {
    if (!progressRef.current || playbackState.duration === 0) return;

    setIsDragging(true);

    const handleMouseMove = (moveEvent: MouseEvent) => {
      if (!progressRef.current) return;

      const rect = progressRef.current.getBoundingClientRect();
      const dragX = Math.max(0, Math.min(moveEvent.clientX - rect.left, rect.width));
      const percentage = dragX / rect.width;
      const newTime = percentage * playbackState.duration;

      setPlaybackState(prev => ({ ...prev, currentTime: newTime }));
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      if (audioRef.current) {
        audioRef.current.currentTime = playbackState.currentTime;
      }
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  }, [playbackState.duration, playbackState.currentTime]);

  const formatTime = (seconds: number): string => {
    if (isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercentage = playbackState.duration > 0
    ? (playbackState.currentTime / playbackState.duration) * 100
    : 0;

  const isDisabled = !audioFile || isAnalyzing;

  // Apply external seek requests (e.g., waveform click)
  useEffect(() => {
    if (seekToTime === null || seekToTime === undefined) return;
    if (!audioRef.current) return;

    const audio = audioRef.current;
    const target = playbackState.duration
      ? Math.max(0, Math.min(seekToTime, playbackState.duration))
      : Math.max(0, seekToTime);

    audio.currentTime = target;
    setPlaybackState(prev => ({ ...prev, currentTime: target }));
    onPlaybackProgress?.(target, playbackState.duration || audio.duration || 0);
    onSeekApplied?.();
  }, [seekToTime, playbackState.duration, onPlaybackProgress, onSeekApplied]);


  return {
    audioRef,
    progressRef,
    visualizationCanvasRef,
    visualizationEngineRef,
    visualizationData,
    setVisualizationData,
    isDragging,
    setIsDragging,
    playbackState,
    setPlaybackState,
    visualizationEnabled,
    isDisabled,
    progressPercentage,
    formatTime,
    togglePlay,
    stopPlayback,
    skipBackward,
    skipForward,
    toggleMute,
    toggleRepeat,
    toggleShuffle,
    setVolume,
    handleProgressClick,
    handleProgressDrag,
  };
}

export type TransportController = ReturnType<typeof useTransportController>;
