import { SkipBack, SkipForward, Play, Pause, Repeat } from 'lucide-react';
import type { TransportController } from './useTransportController';

interface Props {
  controller: TransportController;
}

export function TransportCompactView({ controller }: Props) {
  const {
    audioRef,
    progressRef,
    skipBackward,
    skipForward,
    togglePlay,
    toggleRepeat,
    handleProgressClick,
    handleProgressDrag,
    isDisabled,
    progressPercentage,
    playbackState,
    formatTime,
  } = controller;


}
