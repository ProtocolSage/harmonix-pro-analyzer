import {
  Play,
  Pause,
  Square,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Repeat,
  Shuffle,
  Activity
} from 'lucide-react';
import type { TransportController } from './useTransportController';
import type { AudioAnalysisResult } from '../../types/audio';

interface Props {
  controller: TransportController;
  analysisData?: AudioAnalysisResult | null;
}

export function TransportFullView({ controller, analysisData }: Props) {
  const {
    audioRef,
    progressRef,
    visualizationCanvasRef,
    visualizationData,
    visualizationEnabled,
    togglePlay,
    stopPlayback,
    skipBackward,
    skipForward,
    toggleMute,
    toggleRepeat,
    toggleShuffle,
    setVolume,
    handleProgressClick,
    handleProgressDrag,
    isDisabled,
    progressPercentage,
    playbackState,
    formatTime,
  } = controller;

    return (
      <div className="hp-transport">
        <audio ref={audioRef} preload="metadata" />
        <div className="hp-transport-buttons">
          <button
            onClick={skipBackward}
            disabled={isDisabled}
            className="hp-transport-btn"
            title="Skip backward 10s"
          >
            <SkipBack className="hp-transport-icon" />
          </button>
          <button
            onClick={togglePlay}
            disabled={isDisabled}
            className="hp-transport-btn hp-transport-btn--primary"
            title={playbackState.isPlaying ? 'Pause' : 'Play'}
          >
            {playbackState.isPlaying ? (
              <Pause className="hp-transport-icon" />
            ) : (
              <Play className="hp-transport-icon" />
            )}
          </button>
          <button
            onClick={skipForward}
            disabled={isDisabled}
            className="hp-transport-btn"
            title="Skip forward 10s"
          >
            <SkipForward className="hp-transport-icon" />
          </button>
          <button
            onClick={toggleRepeat}
            disabled={isDisabled}
            className={`hp-transport-btn ${playbackState.isRepeat ? 'is-active' : ''}`}
            title="Repeat"
          >
            <Repeat className="hp-transport-icon" />
          </button>
        </div>
        <div className="hp-transport-progress">
          <div
            ref={progressRef}
            className="hp-transport-track"
            onClick={handleProgressClick}
            onMouseDown={handleProgressDrag}
          >
            <div
              className="hp-transport-fill"
              style={{ width: `${progressPercentage}%` }}
            />
          </div>
          <div className="hp-transport-time">
            <span>{formatTime(playbackState.currentTime)}</span>
            <span>{formatTime(playbackState.duration)}</span>
          </div>
        </div>
        {visualizationEnabled && (
          <div className="hp-transport-mini-visual">
            <canvas ref={visualizationCanvasRef} className="hp-transport-mini-meter" />
          </div>
        )}
      </div>
    );
}
